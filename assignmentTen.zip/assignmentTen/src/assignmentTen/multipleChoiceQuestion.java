package assignmentTen;

import java.util.ArrayList;
import java.util.List;

// we again extend question
public class multipleChoiceQuestion extends question{
	private int correctAnswer;
	private String[] possibleAnswers = String[5];
	
	public multipleChoiceQuestion(int points, int difficulty, int answerSpace, String questionText, String answerText, String[] possibleAnswers) {
		super(points, difficulty, answerSpace, questionText);
		this.correctAnswer = correctAnswer;
		this.possibleAnswers = possibleAnswers;
	}
	
	// getter method
	public int getCorrectAnswer() {
		return this.correctAnswer;
	}
	
	// to display a multiple choice question we want to print out the question
	// under the question we will print a blank line followed by the possible 
	// answers on each of their own lines. 
	public String toString() {
		StringBuilder toString = new StringBuilder();
		// first we append the question as well as a blank line
		toString.append(getQuestionText());
		toString.append("\n"); 
		
		// for each option in our possible answers we print it on its own line like 
		// we would see on a test by appending it to our string
		for (int i = 0; i < possibleAnswers.length; i++) {
			toString.append((i + 1) + ": " + possibleAnswers[i]);
		}
		return toString.toString();
	}
	
	// this method will be the same as the toString() method but the answer needs to 
	// look like **** <correct answer> ****
	// since we made getCorrectAnswer() return the index of the correct answer we can
	// use that here in our for loop to check if the answer is correct
	public String answerToString() {
		StringBuilder toString = new StringBuilder();
		toString.append(getQuestionText());
		toString.append("\n");
		
		for (int i = 0; i < possibleAnswers.length; i++) {
			if (i != getCorrectAnswer()) {
				toString.append((i + 1) + ": " + possibleAnswers[i]);
			} else {
				(i + 1) + ": " + "****" + possibleAnswers[i] + "****"
			}
		}
		return toString.toString();
	}
}
