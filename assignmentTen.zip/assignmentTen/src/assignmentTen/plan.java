package assignmentTen;

public class plan {
	// first class made is going to be the question class that holds the main variables
//	that every single type of question will have ( does not matter if it is a multiple choice 
//	or fill in the blank. each question has points, dificulty, answerspace, questiontext, and a 
//	correct answer. We will leave correct answer to be declared as private in the specific question classes
//	
	// the rest of the classes are also questions but may be different types of questions
	

}
