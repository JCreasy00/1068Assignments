package assignmentTen;


// we extend question since, like we talked about in class, Objective question etc are a type of
// question themselves, so we extend the question class and super in the values
public class objectiveQuestion extends question {
	// all we need to introduce as far as new variables go is the correct answer
	private String answerText;
	
	
	public objectiveQuestion(int points, int difficulty, int answerSpace, String questionText, String answerText) {
		super(points, difficulty, answerSpace, questionText);
		this.answerText = answerText;
	  }
	
	
	// grabber class
	public String getCorrectAnswer() {
		return this.answerText;
	}
	
	public String toString() {
		return this.getQuestionText();
	}
	
	public String answerToString() {
		return getQuestionText() + "\nAnswer" + this.answerText;
	}
}
