package assignmentTen;

import java.util.ArrayList;
import java.util.List;

public class test {
	private List<Object> questions = new ArrayList<Object>();
	private int totalPoints;

    public void Test(List<Object> questions) {
        this.questions = questions;
        for (Object question : questions) {
            this.totalPoints += ((question) question).getPoints();
        }
    }

    public void addQuestion(question question) {
        this.questions.add(question);
        this.totalPoints += question.getPoints();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Test: worth " + totalPoints +  "points\n");
        
        for (int i = 0; i < questions.size(); i++) {
            sb.append((i + 1) + ": \n" + this.questions.get(i).toString());
        }
        return sb.toString();
    }

    public String answerKeyToString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Test: worth " + totalPoints +  "points\n");
        
        for (int i = 0; i < this.questions.size(); i++) {
            String answer = null;         
            // this chunk of if statements is to determine what type of question we are dealing with
            // credit to @All_Hail_The_Sheep for the help with the logic behind this 
            // as well as the syntax
            if (this.questions.get(i) instanceof objectiveQuestion) {
                answer = ((objectiveQuestion)this.questions.get(i)).answerToString();
            } else if (this.questions.get(i) instanceof fillInTheBlankQuestion) {
                answer = ((fillInTheBlankQuestion)this.questions.get(i)).answerToString();
            } else if (this.questions.get(i) instanceof multipleChoiceQuestion) {
                answer = ((multipleChoiceQuestion)this.questions.get(i)).answerToString();
            } else {
            	// if we get an error
                System.err.println("Object at index" + i + "is an unknown question type!");
                System.exit(1);
            }
            
            sb.append((i + 1) + ": " + answer+"\n");
        }
        return sb.toString();
    }
}
