package assignmentTen;

// again extend question
public class fillInTheBlankQuestion extends question{
	// this will look a lot like the objective question class
	private String answerText;
	
	
	//constructor
	public fillInTheBlankQuestion(int points, int difficulty, int answerSpace, String questionText, String answerText) {
		super(points, difficulty, answerSpace, questionText);
		this.answerText = answerText;
	}
	
	// grabber
	public String getAnswerText() {
		return this.getAnswerText();
	}
	
	public String toString() {
		return getQuestionText();
	}
	
	public String answerToString() {
		String temp = "_____" + getAnswerText();
		return getAnswerText() + "\nAnswer : " + temp + getAnswerText();
	}
}

