package assignmentTen;

public abstract class question {
	// assign the variables given to us in the prompt
	private int points, difficulty, answerSpace;
	private String questionText;
	// we also need a max and a min, I will make is so that if the difficulty passed
	// in the difficulty parameter is less than 1 it will be changed to 1 and if it is 
	// greater than 10 it gets set back down to 10.
	private static final int MIN_DIFFICULTY = 1;
	private static final int MAX_DIFFICULTY = 10;
	
	
	// constructor method
	// included is a if statement keeping the difficulty between 1 and 10.
	public question(int points, int difficulty, int answerSpace, String questionText) {
		this.points = points;
		
		if (difficulty < MIN_DIFFICULTY) {
			difficulty = 1;
			this.difficulty = difficulty;
		} else if (difficulty > MAX_DIFFICULTY){
			difficulty = 10;
			this.difficulty = difficulty;
		} else {
			this.difficulty = difficulty;
		}
		
		this.answerSpace = answerSpace;
		this.questionText = questionText;
	}
	
	
	// grabber methods
	public int getPoints() {
		return this.points;
	}
	
	public int getDifficulty() {
		return this.difficulty;
	}
	
	public int getAnswerSpace() {
		return this.answerSpace;
	}
	
	public String getQuestionText() {
		return this.questionText;
	}
	
}
