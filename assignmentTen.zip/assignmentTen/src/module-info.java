module assignmentTen {
}