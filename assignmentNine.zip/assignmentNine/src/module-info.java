module assignmentNine {
	exports assignmentNine;
}