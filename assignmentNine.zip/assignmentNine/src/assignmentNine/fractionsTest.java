package assignmentNine;

public class fractionsTest {
	public static void main(String[] args) {
        fractions myFraction = new fractions(4, 16);
        System.out.println(myFraction.toString());
        System.out.println(myFraction.equals(new fractions(2, 8)));
        myFraction.setNum(2);
        myFraction.setDenom(6);
    }
}
