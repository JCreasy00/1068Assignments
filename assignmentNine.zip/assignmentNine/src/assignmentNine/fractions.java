package assignmentNine;

public class fractions {
	private int n, d;

    public fractions(int n, int d) {
    	 // check if d is equal to zero
    	if (d == 0) {
    		throw new ArithmeticException();     
    	}
        int gcd = gcd(n, d);
        this.n = n / gcd;
        this.d = d / gcd;
    }
    // getter for numerator
    public int getNum() {
        return this.n;
    }
 // getter for numerator
    public int getDenom() {
        return this.d;
    }
    // sets the numerator field to the value given in n 
    public void setNum(int n) {
        int gcd = gcd(n, this.d);
        this.n = n / gcd;
    }
    // set the denominator field to the given value 
    public void setDenom(int d) {
    	if (d == 0) {
    		throw new ArithmeticException();     
    	}
        int gcd = gcd(this.n, d);
        this.d = d / gcd;
    }

    public String toString() {
        return String.format(this.n + " " + this.d);
    }
    // credit to AllHailTheSheep on github for the gcd function that takes in two numbers and returns the gcd
    public int gcd(int a, int b) {
        if (a == 0)
            return b;
        return gcd(b % a, a);
    }
}
