package assignmentNine;

public class car {
	// setting up all of the variables given to us by the prompt
	private String make, model;
	private int year;
	// fill tank takes a double so make the gas as well as the miles a double
	private double MPG, milesDriven, fuelCapacity, fuelRemaining;
	
	public car(int i, String string, String string2, double d, double e, double f, double g) {
		this.make = string;
		this.model = string2;
	    this.year = i;
	    this.fuelCapacity = d;
	    this.MPG = e;
	    this.milesDriven = f;
	    this.fuelRemaining = g;
	}

	// enter a new car in the form..."This is a 2016 toyota camry with x amount of miles dirven on the tank
	// that gets y miles per gallon. It can hold this much fuel and has this amount in it at the moment
//	public void car(int carYear, String carModel, String carMake, double carMilesDriven, double carMPG, double carFuelCapacity, double carFuelRemaining) {
//		this.make = carMake;
//		this.model = carModel;
//	    this.year = carYear;
//	    this.fuelCapacity = carFuelCapacity;
//	    this.MPG = carMPG;
//	    this.milesDriven = carMilesDriven;
//	    this.fuelRemaining = carFuelRemaining;
//}
//	
	// filling our tank up
	public void fillTank(double g) {
		if (g + fuelRemaining > this.fuelCapacity) {
			fuelRemaining = this.fuelCapacity;
		} else {
			this.fuelRemaining = this.fuelRemaining + g; // * possible undeeded this
		}
	}
	public void drive(double m) {
		// we want to check if it takes more fuel than we have to get 
		// to our destination, we can find out fuel necessary to get to
		// our destination by doing to following
		// necessary fuel = distance / our current MPG 
		// if we want to drive 10 miles while only getting 2.5 mpg
		// you need 10/2.5 = 4 gallons of gas
		
		double x = m / this.MPG;
		// if fuel needed is less than the amount of gas we have
		// head to our destination
		if (x <= this.fuelRemaining) {
			// prompt says to add to our miles driven 
			this.milesDriven += m;
			this.fuelRemaining -= x;
		} else {
			this.milesDriven = x - this.fuelRemaining;
			System.out.println("I can only take you " + (x - this.fuelRemaining) + "miles towards your final destination");
		}
	}
	// return what our car specs are currenty in the form of a string
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format(this.year + " " + this.make + " " + this.model + " "));
        sb.append(String.format("Max Gas: " + " " + this.fuelCapacity + " "));
        sb.append(String.format("Current MPG" + " " + this.MPG + " "));
        sb.append(String.format("Amount of Miles dirven" + " " + this.milesDriven + " "));
        sb.append(String.format("Fuel Left" + " " + this.fuelRemaining));
        return sb.toString();
		
	}
	// i think we called these getter methods in class or something like that
	public double getFuelRemaining() {
		return this.fuelRemaining;

		}
}