package assignmentNine;

public class carTest {
	public static void main(String[] args) {
        car myCar = new car(2016, "Toyota", "Camry", 100.0, 25.0, 325.0, 225.0);
        myCar.drive(113);
        System.out.println(myCar.getFuelRemaining());
        myCar.fillTank(85);
        myCar.drive(50);
        System.out.println(myCar.toString());
    }
}
